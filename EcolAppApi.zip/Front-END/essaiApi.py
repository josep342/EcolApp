import requests
from datetime import datetime


rep=requests.get('http://127.0.0.1:8000/api/classe/1')

if rep.status_code==200:

    listinfo=rep.json()
    
    listinfo=listinfo.get("classe",[])

    for i in listinfo.values():

        print(i)

print('sepa')

tabval=[]

listinfo=[]

data={
    "name":"50e"
}
#rep=requests.post('http://127.0.0.1:8000/api/classe/create',json=data)

#rep=requests.put('http://127.0.0.1:8000/api/classe/edit/'+str(2),json=data)



data={
    "title":"rien essai dehors",
    "content":"content essai",
    "file":"file essai",
    "users_id":14
}

#rep=requests.post('http://127.0.0.1:8000/api/communique/create',json=data)
v2="lcl"
v3="kokoso"
v4="kokoso"
v5="kokoso"
v6="kokoso"
v7=15
v8=15
v9=2
v10=4

v1="type trav new show"

data={
                
    "name":v1
}

rep=requests.post('http://127.0.0.1:8000/api/typeTravail/create',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False
        
if rep.status_code==200:
    
    print("effectué")

