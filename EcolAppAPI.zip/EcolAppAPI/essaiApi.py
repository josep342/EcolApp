import requests
from datetime import datetime


rep=requests.get('http://127.0.0.1:8000/api/classe/1')

if rep.status_code==200:

    listinfo=rep.json()
    
    listinfo=listinfo.get("classe",[])

    for i in listinfo.values():

        #print(i)
        pass


listinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/cours/')

if rep.status_code==200:

    tabval=rep.json()
    
    tabval=tabval.get('cours',[])

    tabval=tabval.get('data',[])

    for i in tabval:
        
        a=i['id']
        b=i['name']
        c=i['ponderation']
        
        xx=i['classe']

        d=xx['id']
        e=xx['name']

        xxx=i['option']

        f=xxx['id']
        g=xxx['name']
        
        xxxx=xxx['section']

        h=xxxx['id']
        j=xxxx['name']

        k=i['created_at']
        l=i['updated_at']

        lign=(a,b,c,d,e,h,g,h,j,k,l)

        listinfo.append(lign)
    
    
    print(listinfo)

