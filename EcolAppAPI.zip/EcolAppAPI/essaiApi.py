import requests
from datetime import datetime

v1=1

data={
    "status":0
}

rep=requests.get('http://127.0.0.1:8000/api/classe/delete/'+str(v1))

if rep.status_code==200:           

    etat=True

else:

    etat=False

print(etat)    

"""rep=requests.get('http://127.0.0.1:8000/api/classe/1')

if rep.status_code==200:

    listinfo=rep.json()
    
    listinfo=listinfo.get("classe",[])

    for i in listinfo.values():

        #print(i)
        pass
 


listinfo=[]
tabinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/user/all')

if rep.status_code==200:

    tabval=rep.json()

    tabval=tabval.get('user')

    #tabval=tabval.get('data')
    #print(tabval)
    
    for li in tabval:

        n1=li['id']
        n2=li['name'] 
        n3=li['first_name'] 
        n4=li['last_name'] 
        n5=li['sexe']
        n6=li['address'] 
        n7=li['phone'] 
        n8=li['file'] 
        n9=li['email']
 
        x=li['fonction'] 
        n10=x['name'] 
        
        n11=li['created_at']
        n12=li['updated_at']

    
        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12)

        listinfo.append(ligne)
    
    print(listinfo)


else:
    print('vide')

"""    
"""
        n3=x['name']

        xx=li['motif']

        n4=xx['name']

        xk=li['tranche']

        nn4=xk['name']

        xxx=li['eleve']

        n5=xxx['id']
        n6=xxx['name']
        n7=xxx['first_name']
        n8=xxx['last_name']
        n9=xxx['sexe']

        xxxx=xxx['user']

        n10=xxxx['name']
        n11=xxxx['first_name']
        n12=xxxx['last_name']
        n13=xxxx['email']


        xxxxx=li['classe']

        n14=xxxxx['name']

        xxxxxxx=xxx['option']

        n15=xxxxxxx['name']

        xxxxxxxx=xxxxxxx['section']
        
        n16=xxxxxxxx['name']


        xxxxxx=li['annee']

        n17=xxxxxx['name']

        n3=li['first_name']
        n4=li['last_name']
        n5=li['sexe']
        n6=li['ecole_provenance']
        n7=li['percent']
        n8=li['phone']

        x=li['classe']

        n9=x['id']
        n10=x['name']

        xx=li['option']

        n11=xx['id']
        n12=xx['name']

        #xxx=xx['section']

        #n8=xxx['id']
        #n9=xxx['name']

        xxxx=li['annee']

        n13=xxxx['id']
        n14=xxxx['name']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)

       x=li['cour']

        n2=x['id']
        n3=x['name']

        xx=li['user']

        n4=xx['id']
        n5=xx['name']
        n6=xx['email']

        xxx=x['classe']

        n7=xxx['id']
        n8=xxx['name']

        xxxxx=x['option']

        n9=xxxxx['id']
        n10=xxxxx['name']

        xxxxxx=xxxxx['section']

        n11=xxxxxx['id']
        n12=xxxxxx['name']

        xxx=li['annee']

        n13=xxx['id']
        n14=xxx['name']

        n15=li['created_at']
        n16=li['updated_at']

        ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)


        tabinfo.append(ligne)
    
    print(tabinfo)

    # essai put sans succes


    data={
    "status":"0"
}

rep=requests.put('http://127.0.0.1:8000/api/classe/delete/{v1}',json=data)

if rep.status_code==200:           

    etat=True

else:

    etat=False

print(etat)

"""
       

    
"""
les cours enseignés dans la classe et option

listinfo=[]

rep=requests.get('http://127.0.0.1:8000/api/cours/classe/1/1')

if rep.status_code==200:

    tabval=rep.json()
    
    print(tabval)
"""