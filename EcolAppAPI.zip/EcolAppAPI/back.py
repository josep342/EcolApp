import mysql.connector
from datetime import datetime
import requests

class EcoleApp:

    def __init__(self):
        
        pass
    
    # les fonction itermedaires

    def affichAttributionSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,sections.name,options.name,classes.name,cours.name,cours.ponderation,anne_scolaires.name,cour_enseigners.created_at,cour_enseigners.updated_at from users,options,sections,cour_enseigners,cours,anne_scolaires,classes where cours.classes_id=classes.id and cours.id=cour_enseigners.cours_id and cour_enseigners.annee_id=anne_scolaires.id and options.id=cours.options_id and options.section_id=sections.id and cour_enseigners.users_id=users.id and sections.id=%s order by users.name ASC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def affichUserSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,fonctions.name,users.email,users.password,users.address,users.phone,users.file,users.created_at,users.updated_at from users,fonctions where fonctions.id=users.fonction_id and fonctions.id=%s and users.status='1' order by users.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def affichCommuniquenowMid(self,dat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.id,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def affichCommuniquenow(self,dat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.updated_at>=%s and communiques.status='1' order by communiques.updated_at DESC",(dat,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def affichCommunique(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,communiques.title,communiques.content,communiques.file,communiques.created_at,communiques.updated_at from communiques,users where communiques.users_id=users.id and communiques.status='1' order by communiques.updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    

    def coursFaireTravailRechercheEns(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.cours_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,v5,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def classFaireTravailRechercheEns(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and classes.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def optionFaireTravailRechercheEns(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def sectionFaireTravailRechercheEns(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select users.name,users.first_name,users.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,travails.created_at,travails.updated_at from cour_enseigners,users,anne_scolaires,classes,type_travails,travails,cours,options,sections where cour_enseigners.annee_id=travails.annee_id and anne_scolaires.id=cour_enseigners.annee_id and options.section_id=sections.id and classes.id=cours.classes_id and cours.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and cour_enseigners.users_id=users.id and cour_enseigners.users_id=cours.id and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def classFaireTravailRecherche(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and eleves.classes_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo

    def optionFaireTravailRecherche(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and eleves.options_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def sectionFaireTravailRecherche(self,v1,v2,v3,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select eleves.name,eleves.first_name,eleves.last_name,type_travails.name,travails.title,cours.name,travails.date_de_remise,classes.name,options.name,sections.name,anne_scolaires.name,faire_travails.created_at,faire_travails.updated_at from anne_scolaires,classes,eleves,faire_travails,type_travails,travails,cours,options,sections where eleves.annee_id=travails.annee_id and anne_scolaires.id=eleves.annee_id and options.section_id=sections.id and classes.id=eleves.classes_id and eleves.options_id=options.id and cours.id=travails.cours_id and type_travails.id=travails.type_travails_id and travails.id=faire_travails.id_travails and eleves.id=faire_travails.id_eleves and options.section_id=%s and travails.type_travails_id=%s and travails.annee_id=%s order by faire_travails.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    

    def coteRecherheCours(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.cours_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,v5,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def coteRecherhePeriode(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.periode_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheClass(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheOption(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def coteRecherheSection(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select cotes.eleves_id,cotes.cote,periodes.name,cours.name,classes.name,options.name,sections.name,anne_scolaires.name,cotes.created_at,cotes.updated_at from cotes,eleves,classes,options,anne_scolaires,sections,periodes,cours where eleves.id=cotes.eleves_id and cours.id=cotes.cours_id and periodes.id=cotes.periode_id and eleves.classes_id=classes.id and eleves.options_id=options.id and cotes.annees_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and cotes.annees_id=%s order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def motifRecherhePaiement(self,v1,v2,v3,v4,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.motifs_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,v4,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def classRecherhePaiement(self,v1,v2,v3,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.classes_id=%s and paiements.annee_id=%s and paiements.classes_id=classes.id order by paiements.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherhePaiement(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
            #cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.updated_at from paiements,eleves,users,classes,options,anne_scolaires,sections where paiements.eleves_id=eleves.id and users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherhePaiement(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,classes.name,options.name,sections.name,anne_scolaires.name,paiements.montant,devises.name,motifs.name,tranches.name,paiements.updated_at from eleves,classes,options,anne_scolaires,sections,paiements,devises,motifs,tranches where tranches.id=paiements.tranches_id and paiements.motifs_id=motifs.id and paiements.devises_id=devises.id and  paiements.eleves_id=eleves.id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and paiements.annee_id=%s order by paiements.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    
    def recupMontant(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def verifpaiement(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            cursor.execute("select montant,updated_at,users_id from paiements where eleves_id=%s and motifs_id=%s and tranches_id=%s and annee_id=%s",(v1,v2,v3,v4))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo


    def coursRechercheUniqueSectionNow(self,v1,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def coursRechercheUniqueOptionNow(self,v1,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def coursRechercheUniqueClassNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s and cours.updated_at > %s order by cours.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    # now fin

    def coursRechercheUniqueSection(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and sections.id=%s order by cours.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def coursRechercheUniqueOption(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s order by cours.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def coursRechercheUniqueClass(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' and options.id=%s and cours.classes_id=%s order by cours.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def classRecherheUniqueeleveNow(self,v1,v2,v3,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherheUniqueeleveNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUniqueeleveNow(self,v1,v2,con):

        datss=str(datetime.now().strftime('%Y-%m-%d'))+" 00:00:00"

        dtt=datetime.strptime(datss,'%Y-%m-%d %H:%M:%S')

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.updated_at > %s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,dtt,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def classRecherheUniqueeleve(self,v1,v2,v3,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.classes_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,v3,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def optionRecherheUniqueeleve(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.options_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUniqueeleve(self,v1,v2,con):

        try:

            cursor=con.cursor()
            cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,users.sexe,eleves.matricule,eleves.description,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and options.section_id=%s and eleves.annee_id=%s and eleves.status='1' order by eleves.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def ClassRecherheUnique(self,v1,v2,con):

        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s and inscriptions.classes_id=%s order by inscriptions.updated_at DESC",(v1,v2,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo
    
    def OptionRecherheUnique(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and inscriptions.options_id=%s order by inscriptions.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def sectionRecherheUnique(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,users.sexe,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,sections.name,anne_scolaires.name,inscriptions.nationalite,fonctions.name,eleves.description,inscriptions.created_at,inscriptions.updated_at from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and sections.id=%s order by inscriptions.updated_at DESC",(v1,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e
        
        return etat,listinfo

    def InscriptionRechercheMatricule(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select inscriptions.id,inscriptions.name,inscriptions.first_name,inscriptions.last_name,inscriptions.date_naissance,inscriptions.lieu_de_naissance,inscriptions.nom_parent,inscriptions.postnom_parent,inscriptions.ecole_provenance,inscriptions.percent,inscriptions.phone,classes.name,options.name,anne_scolaires.name,inscriptions.created_at,inscriptions.updated_at,inscriptions.nationalite,users.sexe,fonctions.name,sections.name,eleves.description from inscriptions,classes,options,sections,anne_scolaires,eleves,users,fonctions where inscriptions.classes_id=classes.id and inscriptions.options_id=options.id and inscriptions.annee_id=anne_scolaires.id and inscriptions.status='1' and eleves.id=inscriptions.id and fonctions.id=users.fonction_id and users.id=inscriptions.id and inscriptions.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.matricule='"+v1+"'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=False

        return etat,listinfo

    def rechupdateInscription(self,opt,cla,mat,con):

        try:
            cursor=con.cursor()
            cursor.execute("select matricule,name from eleves where status=%s and options_id=%s and classes_id=%s and matricule like'%"+mat+"%' order by name ASC",('1',opt,cla,))
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except Exception as e:
            listinfo=[]
            etat=e

        return etat,listinfo
    
    def  optionProxRecherche(self,v1,con):

        try:
            cursor=con.cursor()
            cursor.execute("select options.id,options.name,sections.name,options.created_at,options.updated_at from options,sections where options.status='1' and options.section_id=sections.id and sections.status=%s and options.section_id=%s order by updated_at DESC",('1',v1,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def TravailRechercheIntIdClass(self,v1,v2,v3,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s and cours.classes_id=%s",(v1,v2,v3,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailRechercheIntIdOption(self,v1,v2,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s and cours.options_id=%s",(v1,v2,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo

    def TravailRechercheIntIdSection(self,v1,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select travails.id,title,description,date_de_remise,cours.name,type_travails.name,classes.name,options.name,sections.name,anne_scolaires.name from sections,classes,travails,cours,type_travails,options,anne_scolaires where travails.status='1' and  cours.id=travails.cours_id and travails.annee_id=anne_scolaires.id and type_travails.id=travails.type_travails_id and cours.options_id=options.id and cours.id=classes.id and sections.id=options.section_id and options.section_id=%s",(v1,))     
            listinfo=cursor.fetchall()   
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    

    # fontions principales

    def UserAjout(self,iduser,v2,gmail,v4,v6,v7,v8,v9,v10,v11,v12,con):
        
        try:
            #query="insert into users(id,name,email,email_verified_at,password,remember_token,created_at,updated_at,first_name,last_name,address,phone,file,fonction_id,status,sexe) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                
                "name":v2,
                "email":gmail,
                "email_verified_at":"",
                "password":v4,
                "remember_token":"",
                "first_name":v6,
                "last_name":v7,
                "address":v8,
                "phone":v9,
                "file":v10,
                "fonction_id":v11,
                "sexe":v12


            }

            rep=requests.post('http://127.0.0.1:8000/api/register',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except Exception as e:
            etat=False

        return etat
    

    def UserRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select users.id,users.name,users.first_name,users.last_name,users.sexe,fonctions.name,users.email,users.password,users.address,users.phone,users.file,users.created_at,users.updated_at from users,fonctions where fonctions.id=users.fonction_id and users.status='1' order by users.updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def UserUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,con):

        try:
            cursor=con.cursor()
            query="update users set name=%s,email=%s,password=%s,updated_at=%s,first_name=%s,last_name=%s,address=%s,phone=%s,file=%s,fonction_id=%s,sexe=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v5,v6,v7,v8,v9,v10,v11,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def UserDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/user/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat



    def TypeTravailAjout(self,v1,v2,con):

        try:
            #query="insert into type_travails(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            
            data={
                
                "name":v2

            }

            rep=requests.post('http://127.0.0.1:8000/api/typeTravail/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def TypeTravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from type_travails where status='1' order by type_travails.created_at ASC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TypeTravailUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update type_travails set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TypeTravailDelete(self,v1,con):

        try:

            rep=requests.get('http://127.0.0.1:8000/api/typeTravail/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def TravailAjout(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        # c n âas important que la direction ajoute un travail

        try:
            #query="insert into travails(id,title,description,date_de_remise,cours_id,type_travails_id,annee_id,created_at,updated_at,file,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                
                "title":v2,
                "file":file,
                "description":v3,
                "date_de_remise":date1,
                "cours_id":v4,
                "type_travails_id":v5,
                "annee_id":v6

            }

            rep=requests.post('http://127.0.0.1:8000/api/travail/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def TravailRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select * from travails where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TravailUpdate(self,v1,v2,v3,date1,v4,v5,v6,file,con):

        try:
            cursor=con.cursor()
            query="update travails set title=%s,description=%s,date_de_remise=%s,cours_id=%s,type_travails_id=%s,annee_id=%s,updated_at=%s,file=%s where id=%s"
            dataa=(v2,v3,date1,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),file,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TravailDelete(self,v1,con):

        try:
            
            
            rep=requests.get('http://127.0.0.1:8000/api/travail/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat

    def TrancheAjout(self,v1,con):

        try:
            #query="insert into tranches(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
            data={
                "name":v1
            }

            rep=requests.post('http://127.0.0.1:8000/api/tranche/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def TrancheRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from tranches where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def TrancheUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update tranches set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def TrancheDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/section/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat



    def SectionAjout(self,v2,con):

        try:
            #query="insert into sections(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
            data={
                "name":v2
            }

            rep=requests.post('http://127.0.0.1:8000/api/section/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def SectionRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from sections where status='1' order by updated_at DESC")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def SectionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update sections set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def SectionDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/section/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def PeriodeAjout(self,v1,v2,con):

        try:
            #query="insert into periodes(id,name,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            
            data={
                "name":v2
            }

            rep=requests.post('http://127.0.0.1:8000/api/periode/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def PeriodeRecherche(self,con):
        
        try:
            cursor=con.cursor()
            cursor.execute("select id,name,created_at,updated_at from periodes where status='1'")
            listinfo=cursor.fetchall()
            con.close()

            etat=True

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PeriodeUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update periodes set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def PeriodeDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/periode/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def PaiementAjout(self,v2,v3,v4,v5,v6,v7,v8,v9,con):
        
        try:
            #query="insert into paiements(montant,devises_id,motifs_id,eleves_id,classes_id,tranches_id,annee_id,created_at,updated_at,users_id) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                "montant":v2,
                "devises_id":v3,
                "motifs_id":v4,
                "eleves_id":v5,
                "classes_id":v6,
                "tranches_id":v7,
                "annee_id":v8,
                "users_id":v9
            }

            rep=requests.post('http://127.0.0.1:8000/api/paiement/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def PaiementRecherche(self,con):
        
        try:
            #cursor.execute("select * from paiements")

            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/paiement')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('paiements')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['montant'] 

                    x=li['devise']

                    n3=x['name']

                    xx=li['motif']

                    n4=xx['name']

                    xk=li['tranche']

                    nn4=xk['name']

                    xxx=li['eleve']

                    n5=xxx['id']
                    n6=xxx['name']
                    n7=xxx['first_name']
                    n8=xxx['last_name']
                    n9=xxx['sexe']

                    xxxx=xxx['user']

                    n10=xxxx['name']
                    n11=xxxx['first_name']
                    n12=xxxx['last_name']
                    n13=xxxx['email']


                    xxxxx=li['classe']

                    n14=xxxxx['name']

                    xxxxxxx=xxx['option']

                    n15=xxxxxxx['name']

                    xxxxxxxx=xxxxxxx['section']
                    
                    n16=xxxxxxxx['name']


                    xxxxxx=li['annee']

                    n17=xxxxxx['name']

                    n18=li['created_at']
                    n19=li['updated_at']

                    ligne=(n1,n2,n3,n4,nn4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19)

                    listinfo.append(ligne)
                    
                etat=True
            else:

                listinfo=[]
                etat=False

        except:
            
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def PaiementUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,con):

        try:
            cursor=con.cursor()
            query="update paiements set montant=%s,devises_id=%s,motifs_id=%s,eleves_id=%s,classes_id=%s,tranches_id=%s,annee_id=%s,updated_at=%s,users_id=%s where id=%s"
            dataa=(float(v2),v3,v4,v5,v6,v7,v8,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v9,v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    
    def OptionAjout(self,v2,v3,con):

        try:
            #query="insert into options(name,section_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s)"
            
            data={
                "name":v2,
                "section_id":v3
            }

            rep=requests.post('http://127.0.0.1:8000/api/option/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def OptionRecherche(self,con):
        
        try:
            #cursor.execute("select options.id,options.name,sections.name,options.created_at,options.updated_at from options,sections where options.status='1' and options.section_id=sections.id and sections.status='1' order by updated_at DESC")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/option')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('option')

                tabval=tabval.get('data')

                #print(tabval)

                for li in tabval:

                    n1=li['id']
                    n2=li['name'] 

                    x=li['section']

                    #n1=x['id']
                    n3=x['name']

                    n4=li['created_at']
                    n5=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5)

                    listinfo.append(ligne)
                    
                etat=True

            else:

                listinfo=[]
                etat=False

        except:

            listinfo=[]
            etat=False

        return etat,listinfo
    
    def OptionUpdate(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update options set name=%s,section_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def OptionDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/option/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def MotifAjout(self,v1,con):

        try:

            data={
                "name":v1

            }

            rep=requests.post('http://127.0.0.1:8000/api/motif/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

            #query="insert into motifs(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
        except:
            etat=False

        return etat
    

    def MotifRecherche(self,con):
        
        try:
            #cursor.execute("select id,name,created_at,updated_at from motifs where status='1' order by updated_at DESC")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/motif')

            if rep.status_code==200:

                tabval=rep.json()


                tabval=tabval.get('motif')

                tabval=tabval.get('data')

                #print(tabval)

                for li in tabval:

                    n1=li['id']
                    n2=li['name'] 
                    n3=li['created_at']
                    n4=li['updated_at']

                    ligne=(n1,n2,n3,n4)

                    listinfo.append(ligne)
                    
                etat=True

            else:

                listinfo=[]
                etat=False

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def MotifUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update motifs set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def MotifDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/motif/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def InscriptionAjout(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,datenaiss,v12,v13,v14,v15,con):

        # faut ajouter le sexe lors de la enregitrement 

        try:
            #query="insert into inscriptions(name,first_name,last_name,ecole_provenance,percent,phone,classes_id,options_id,annee_id,created_at,updated_at,status,date_naissance,lieu_de_naissance,nationalite,nom_parent,postnom_parent) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                "name":v1,
                "first_name":v2,
                "last_name":v3,
                "sexe":v4,
                "ecole_provenance":v5,
                "percent":v6,
                "phone":v7,
                "classes_id":v8,
                "options_id":v9,
                "annee_id":v10,

                "date_naissance":datenaiss,
                "lieu_de_naissance":v12,
                "nationalite":v13,
                "nom_parent":v14,
                "postnom_parent":v15

            }

            rep=requests.post('http://127.0.0.1:8000/api/inscription/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False
        except:
            etat=False

        return etat
    

    def InscriptionRecherche(self,con):
        
        try:
            #cursor.execute("select * from inscriptions where status='1'")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/inscription')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('inscriptionEnAttente')

                #tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['name'] 
                    n3=li['first_name']
                    n4=li['last_name']
                    n5=li['sexe']
                    n6=li['ecole_provenance']
                    n7=li['percent']
                    n8=li['phone']

                    x=li['classe']

                    n9=x['id']
                    n10=x['name']

                    xx=li['option']

                    n11=xx['id']
                    n12=xx['name']

                    #xxx=xx['section']

                    #n8=xxx['id']
                    #n9=xxx['name']

                    xxxx=li['annee']

                    n13=xxxx['id']
                    n14=xxxx['name']

                    n15=li['created_at']
                    n16=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)

                    listinfo.append(ligne)
                    
                etat=True

            else:

                listinfo=[]
                etat=False

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def InscriptionUpdate(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,v11,v12,v13,v14,v15,con):
        
        try:
            cursor=con.cursor()
            query="update inscriptions set name=%s,first_name=%s,last_name=%s,ecole_provenance=%s,percent=%s,phone=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s,date_naissance=%s,lieu_de_naissance=%s,nationalite=%s,nom_parent=%s,postnom_parent=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v11,v12,v13,v14,v15,int(v1))
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def InscriptionDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/inscription/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat

    def HoraireAjout(self,v1,v2,v3,v4,v5,v6,con):

        try:
            #query="insert into horaires(id,title,image,classes_id,options_id,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                "title":"titrien",
                "image":"imah.png",
                "classes_id":15,
                "options_id":1,
                "annee_id":4
            }

            rep=requests.post('http://127.0.0.1:8000/api/horaire/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def HoraireRecherche(self,con):
        
        try:
            #cursor.execute("select * from horaires where status='1'")
        
            listinfo=[]
            
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/horaire')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('horaire')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['title'] 
                    n3=li['image']

                    x=li['classe']

                    n4=x['id']
                    n5=x['name']

                    xx=li['option']

                    n6=xx['id']
                    n7=xx['name']

                    xxx=xx['section']

                    n8=xxx['id']
                    n9=xxx['name']

                    xxxx=li['annee']

                    n10=xxxx['id']
                    n11=xxxx['name']

                    n12=li['created_at']
                    n13=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n12,n13)

                    listinfo.append(ligne)
                    
                etat=True

            else:
                
                listinfo=[]
                etat=False

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def HoraireUpdate(self,v1,v2,v3,v4,v5,v6,con):

        try:
            cursor=con.cursor()
            query="update horaires set title=%s,image=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,v6,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def HoraireDelete(self,v1,con):

        try:

            pass

        except:
            etat=False
        
        return etat


    def FonctionAjout(self,v1,con):

        try:
            #query="insert into fonctions(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
            data={
                "name":v1
            }

            rep=requests.post('http://127.0.0.1:8000/api/fonction/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def FonctionRecherche(self,con):
        
        try:
            
            #cursor.execute("select id,name,created_at,updated_at from fonctions where status='1' order by updated_at DESC")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/fonction')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('fonction')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['name'] 
                    n3=li['created_at']
                    n4=li['updated_at']

                    ligne=(n1,n2,n3,n4)

                    listinfo.append(ligne)

                    etat=True
            else:
                
                listinfo=[]
                etat=False    
        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FonctionUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update fonctions set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def FonctionDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/fonction/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def FaireTravailRecherche(self,con):
        
        try:
            #cursor.execute("select * from faire_travails where status='1'")
            
            listinfo=[]

            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/faire')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('faire_travail')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id_travails']

                    xx=li['travail']

                    n2=xx['id']
                    n3=xx['titre'] 
                    n2=xx['description']
                    n4=xx['fichier'] 
                    n5=xx['date_remise'] 

                    xxx=xx['cour']

                    n6=xxx['id']
                    n7=xxx['name'] 

                    xxxx=xx['typetravail']

                    n8=xxxx['id']
                    n9=xxxx['name'] 

                    xxxxx=xx['annee']

                    n10=xxxxx['id']
                    n11=xxxxx['name'] 

                    xxxxx=li['eleve']

                    n12=xxxxx['id']
                    n13=xxxxx['name'] 
                    n14=xxxxx['first_name']
                    n15=xxxxx['last_name'] 
                    n16=xxxxx['sexe'] 

                    xxxxxx=xxxxx['user']

                    n17=xxxxxx['id']
                    n18=xxxxxx['name']
                    n19=xxxxxx['email']

                    xxxxxxx=xxxxx['classe']

                    n20=xxxxxxx['id']
                    n21=xxxxxxx['name']

                    xxxxxxxx=xxxxx['option']

                    n22=xxxxxxxx['id']
                    n23=xxxxxxxx['name']

                    xxxxxxxxx=xxxxxxxx['section']

                    n24=xxxxxxxxx['id']
                    n25=xxxxxxxxx['name']

                    xxxxxxxxxx=xx['annee']

                    n26=xxxxxxxxxx['id']
                    n27=xxxxxxxxxx['name']

                    n28=li['created_at']
                    n29=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,n20,n21,n22,n23,n24,n25,n26,n27,n28,n29)


                    listinfo.append(ligne)
                    etat=True
            else:

                listinfo=[]
                etat=False

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def FaireTravailDelete(self,v1,con):

        try:
            
            pass

        except:
            etat=False
        
        return etat
    
    def EleveAjout(self,v1,v2,v3,v4,v5,v6,v7,v8,v9,v10,con):

        # faut ajour le sexe du coté back-END

        try:
            #query="insert into eleves(name,first_name,last_name,matricule,description,users_id,classes_id,options_id ,annee_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                "name":v1,
                "first_name":v2,
                "last_name":v3,
                "sexe":v4,
                "matricule":v5,
                "description":v6,
                "users_id":v7,
                "classes_id":v8,
                "options_id":v9,
                "annee_id":v10
            }

            rep=requests.post('http://127.0.0.1:8000/api/eleve/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat
    

    def EleveRecherche(self,con):
        
        try:
            #cursor.execute("select eleves.id,eleves.name,eleves.first_name,eleves.last_name,eleves.matricule,eleves.description,users.name,classes.name,options.name,sections.name,anne_scolaires.name,eleves.created_at,eleves.updated_at from eleves,users,classes,options,anne_scolaires,sections where users.id=eleves.users_id and eleves.classes_id=classes.id and eleves.options_id=options.id and eleves.annee_id=anne_scolaires.id and sections.id=options.section_id and eleves.status='1'")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/eleve')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('eleve')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['name']
                    n3=li['first_name'] 

                    n4=li['last_name']
                    n5=li['sexe']
                    n6=li['matricule']
                    n7=li['description']

                    xx=li['user']

                    n8=xx['id']
                    n9=xx['name']
                    n10=xx['email']

                    xxx=li['classe']

                    n11=xxx['id']
                    n12=xxx['name']

                    xxxxx=li['option']

                    n13=xxxxx['id']
                    n14=xxxxx['name']

                    xxxxxx=xxxxx['section']

                    n15=xxxxxx['id']
                    n16=xxxxxx['name']

                    xxx=li['annee']

                    n17=xxx['id']
                    n18=xxx['name']

                    n19=li['created_at']
                    n20=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16,n17,n18,n19,n20)


                    listinfo.append(ligne)
                    
                etat=True

            else:

                listinfo=[]
                etat=False            
        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def ElveUpdate(self,v1,v2,v3,v5,v7,v8,v9,v10,con):

        try:
            cursor=con.cursor()
            query="update eleves set name=%s,first_name=%s,last_name=%s,description=%s,classes_id=%s,options_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v5,v7,v8,v9,v10,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def EleveDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/eleve/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat


    def DeviseRecherche(self,con):
        
        try:

            #cursor.execute("select id,name,created_at,updated_at from devises where status='1' order by updated_at DESC")

            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/devise')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('devise')

                tabval=tabval.get('data')

                for li in tabval:

                    n1=li['id']
                    n2=li['name']
                    n3=li['created_at']
                    n4=li['updated_at']

                    ligne=(n1,n2,n3,n4)

                    listinfo.append(ligne)
            else:

                listinfo=[]
                etat=False

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def DeviseUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update devises set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def DeviseDelete(self,v1,con):

        try:
            
            rep=requests.get('http://127.0.0.1:8000/api/devise/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False
        
        except:
            etat=False
        
        return etat
    
    def DevisetAjout(self,v1,con):

        try:
            
            data={

                "name":v1
            }

            rep=requests.post('http://127.0.0.1:8000/api/devise/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:

            etat=False

        return etat


    def CoursEnseignantRecherche(self,con):
        
        try:
            #cursor.execute("select * from cour_enseigners")
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/coursens')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('courEns')

                for li in tabval:

                    n1=li['id']
                    
                    x=li['cour']

                    n2=x['id']
                    n3=x['name']

                    xx=li['user']

                    n4=xx['id']
                    n5=xx['name']
                    n6=xx['email']

                    xxx=x['classe']

                    n7=xxx['id']
                    n8=xxx['name']

                    xxxxx=x['option']

                    n9=xxxxx['id']
                    n10=xxxxx['name']

                    xxxxxx=xxxxx['section']

                    n11=xxxxxx['id']
                    n12=xxxxxx['name']

                    xxx=li['annee']

                    n13=xxx['id']
                    n14=xxx['name']

                    n15=li['created_at']
                    n16=li['updated_at']

                    ligne=(n1,n2,n3,n4,n5,n6,n7,n8,n9,n10,n11,n12,n13,n14,n15,n16)


                    listinfo.append(ligne)
            else:

                listinfo=[]
                etat=False
        except:

            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursEnseignantUpdate(self,v1,v2,v3,v4,con):

        try:
            cursor=con.cursor()
            query="update cour_enseigners set cours_id=%s,users_id=%s,annee_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,datetime.now().strftime('%Y-%m-%d'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursEnseignantAjout(self,v1,v2,v3,v4,con):

        try:
            #query="insert into cour_enseigners(id,cours_id,users_id,annee_id,created_at,updated_at) values(%s,%s,%s,%s,%s,%s)"
            
            data={
                "cours_id":v2,
                "users_id":v3,
                "annee_id":v4
            }

            rep=requests.post('http://127.0.0.1:8000/api/coursens/create',json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False

        return etat

    def CoursRechercheProx(self,v1,v2,con):
        
        try:
            
            listinfo=[]
            tabinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/cours/classe/1/1')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('cours')

                for li in tabval:

                    a=li['id']
                    b=li['name']
                    c=li['ponderation']
                    d=li['classes_id']
                    e=li['options_id']
                    f=li['created_at']
                    g=li['updated_at']

                    h=""

                    ligne=(a,b,c,d,e,f,g,h)

                    tabinfo.append(ligne)

                    etat=True
            
            else:
            
                listinfo=[]
                etat=False       

            #cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.options_id=%s and cours.classes_id=%s and cours.status='1' order by cours.updated_at DESC",(v1,v2,))
            
        except:

            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursRecherche(self,con):
        
        try:
            
            #cursor.execute("select cours.id,cours.name,cours.ponderation,classes.name,options.name,sections.name,cours.created_at,cours.updated_at from cours,classes,options,sections where cours.classes_id=classes.id and cours.options_id=options.id and sections.id=options.section_id and cours.status='1' order by cours.updated_at DESC")
            
            listinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/cours/')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get('cours',[])

                tabval=tabval.get('data',[])

                for i in tabval:
                    
                    a=i['id']
                    b=i['name']
                    c=i['ponderation']
                    
                    xx=i['classe']

                    d=xx['id']
                    e=xx['name']

                    xxx=i['option']

                    f=xxx['id']
                    g=xxx['name']
                    
                    xxxx=xxx['section']

                    h=xxxx['id']
                    j=xxxx['name']

                    k=i['created_at']
                    l=i['updated_at']

                    lign=(a,b,c,d,e,h,g,h,j,k,l)

                    listinfo.append(lign)

                etat=True
                
            else:

                etat=False
                listinfo=[]
        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CoursUpdate(self,v1,v2,v3,con):

        try:
            cursor=con.cursor()
            query="update cours set name=%s,ponderation=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CoursDelete(self,v1,con):

        try:

            rep=requests.get('http://127.0.0.1:8000/api/cours/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat
    
    def CoursAjout(self,v1,v2,v3,v4,con):

        try:
            
            #query="insert into cours(name,ponderation,classes_id,options_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s)"
            
            data={
                "name":v1,
                "ponderation":v2,
                "classes_id":v3,
                "options_id":v4
            }
            
            rep=requests.post('http://127.0.0.1:8000/api/cours/create',json=data)

            if rep.status_code==200:           

                etat=True
            else:
                etat=False


        except:
            etat=False

        return etat

    def CommuniqueRecherche(self,con):
        
        try:
           
            #cursor.execute("select * from communiques where status='1'")
            
            listinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/communique/')

            if rep.status_code==200:

                tabval=rep.json()

                tabval=tabval.get('communiqueAll',[])

                for i in tabval:

                    a=i['id']

                    b=i['title']
                    c=i['content']
                    d=i['file']
                    e=i['users_id']
                    h=i['created_at']
                    j=i['updated_at']

                    lign=(a,b,c,d,e,h,j)

                    listinfo.append(lign)
            
                etat=True   

            else:

                etat=False
                listinfo=[]

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def CommuniqueUpdate(self,v1,v2,v3,v4,v5,con):

        try:
            cursor=con.cursor()
            query="update communiques set title=%s,content=%s,file=%s,users_id=%s,updated_at=%s where id=%s"
            dataa=(v2,v3,v4,v5,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def CommuniqueDelete(self,v1,con):

        try:

            rep=requests.get('http://127.0.0.1:8000/api/communique/delete/'+str(v1))

            if rep.status_code==200:

                etat=True   

            else:

                etat=False
                
        except:
            etat=False
        
        return etat
    
    def CommuniqueAjout(self,v1,v2,v3,v4,con):

        try:

            #query="insert into communiques(title,content,file,users_id,created_at,updated_at,status) values(%s,%s,%s,%s,%s,%s,%s)"

            data={
                "title":v1,
                "content":v2,
                "file":v3,
                "users_id":v4
            }
            
            rep=requests.post('http://127.0.0.1:8000/api/communique/create',json=data)

            if rep.status_code==200:           

                etat=True
            else:
                etat=False


        except:
            etat=False

        return etat



    def Anne_ScolaireRecherche(self,con):
        
        try:

            #cursor.execute("select id,name,created_at,updated_at from anne_scolaires where status='1' order by updated_at DESC")
            
            listinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/annee/')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get("annee",[])

                tabval=tabval.get("data",[])

                for i in tabval:

                    a=i['id']
                    b=i['name']
                    c=i['created_at']
                    d=i['updated_at']

                    ligne=(a,b,c,d)

                    listinfo.append(ligne)

                etat=True   

            else:

                etat=False
                listinfo=[]


        except:
            listinfo=[]
            etat=False

        return etat,listinfo
    
    def AnneSColaireUpdate(self,v1,v2,con):

        try:
            cursor=con.cursor()
            query="update anne_scolaires set name=%s,updated_at=%s where id=%s"
            dataa=(v2,datetime.now().strftime('%Y-%m-%d %H:%M:%S'),v1)
            cursor.execute(query,dataa)
            con.commit()
            
            con.close()

            etat=True
        except:
            etat=False
        
        return etat

    def AnnScolaireDelete(self,v1,con):

        try:
            rep=requests.get('http://127.0.0.1:8000/api/annee/delete/'+str(v1))

            if rep.status_code==200:
                
                etat=True   

            else:

                etat=False
                
        except:
            etat=False
        
        return etat
    
    def AnneSColaireAjout(self,v1,con):

        etat=1

        try:
            #query="insert into anne_scolaires(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
            data={
                "name":v1
            }
            
            rep=requests.post('http://127.0.0.1:8000/api/annee/create',json=data)

            if rep.status_code==200:           

                etat=True
            else:
                etat=False

        except:

            etat=False

        return etat
    
    def classRecherche(self,con):
        
        try:

            listinfo=[]

            rep=requests.get('http://127.0.0.1:8000/api/classe/')

            if rep.status_code==200:

                tabval=rep.json()
                
                tabval=tabval.get("classes",[])

                tabval=tabval.get("data",[])

                for i in tabval:

                    a=i['id']
                    b=i['name']
                    c=i['created_at']
                    d=i['updated_at']

                    ligne=(a,b,c,d)

                    listinfo.append(ligne)

                etat=True   

            else:

                etat=False
                listinfo=[]

            #cursor.execute("select id,name,created_at,updated_at from classes where status='1' order by updated_at DESC")

        except:
            listinfo=[]
            etat=False

        return etat,listinfo
        


    def classAjout(self,v1,con):

        try:

            data={
                "name":v1
            }
            
            rep=requests.post('http://127.0.0.1:8000/api/classe/create',json=data)

            if rep.status_code==200:           

                etat=True
            else:
                etat=False
            #query="insert into classes(name,created_at,updated_at,status) values(%s,%s,%s,%s)"
            
        except:
            etat=False

        return etat
    
    def classUpdate(self,v1,v2,con):

        try:

            data={
                "name":v2
            }

            rep=requests.put('http://127.0.0.1:8000/api/classe/edit/'+str(v1),json=data)

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False

        except:
            etat=False
        
        return etat

    def classDelete(self,v1,con):

        try:

            rep=requests.get('http://127.0.0.1:8000/api/classe/delete/'+str(v1))

            if rep.status_code==200:           

                etat=True
            
            else:

                etat=False
        except:
            etat=False
        
        return etat
    
    def connecteBD():

        try:
            #con=mysql.connector.connect(
            #host="localhost",
            #user="askyas",
            #password="askyas",
            #database="EcolApp"
            #)

            #return con
            pass

        except:
            pass
